package robotService.models.procedures;

import robotService.models.robots.interfaces.Robot;

public class Work extends BaseProcedure {
    private static final int HAPPINESS = 12;
    private static final int ENERGY = 6;

    @Override
    public void doService(Robot robot, int procedureTime) {
        super.doService(robot, procedureTime);

        int newHappiness = robot.getHappiness() + HAPPINESS;
        int newEnergy = robot.getEnergy() - ENERGY;
        robot.setHappiness(newHappiness);
        robot.setEnergy(newEnergy);

    }
}
